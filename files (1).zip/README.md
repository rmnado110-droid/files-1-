# Aplikasi Ekstraksi Fitur Warna
Instalasi : pip install -r requirements.txt
Menjalankan: streamlit run app_streamlit.py
Berkas    : fitur_warna.py (modul inti), app_streamlit.py (antarmuka), requirements.txt
