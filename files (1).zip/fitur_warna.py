"""
fitur_warna.py - Modul inti ekstraksi fitur warna citra digital.
Fitur: momen warna (RGB & HSV), histogram warna, warna dominan (K-Means),
dan penamaan warna dominan berdasarkan Hue.
Dependensi: numpy, opencv-python, pandas
"""
import numpy as np
import cv2
import pandas as pd

NAMA_KANAL_RGB = ["R", "G", "B"]
NAMA_KANAL_HSV = ["H", "S", "V"]


def baca_rgb(data_bytes: bytes) -> np.ndarray:
    """Decode bytes gambar -> array RGB uint8 (H x W x 3)."""
    arr = np.frombuffer(data_bytes, np.uint8)
    bgr = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if bgr is None:
        raise ValueError("File bukan gambar yang valid.")
    return cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)


def ubah_ukuran(rgb: np.ndarray, sisi_maks: int = 400) -> np.ndarray:
    """Perkecil citra (jaga rasio) agar proses cepat."""
    h, w = rgb.shape[:2]
    skala = sisi_maks / max(h, w)
    if skala >= 1:
        return rgb
    return cv2.resize(rgb, (int(w * skala), int(h * skala)), interpolation=cv2.INTER_AREA)


def rgb_ke_hsv(rgb: np.ndarray) -> np.ndarray:
    """RGB uint8 -> HSV float: H derajat [0,360), S dan V [0,1]."""
    hsv = cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV).astype(np.float64)
    hsv[..., 0] *= 2.0      # OpenCV: H 0..179 -> derajat 0..358
    hsv[..., 1] /= 255.0
    hsv[..., 2] /= 255.0
    return hsv


def momen_warna(kanal: np.ndarray) -> dict:
    """Tiga momen warna: mean, standar deviasi, skewness."""
    x = kanal.astype(np.float64).ravel()
    mean = x.mean()
    std = x.std()
    skew = 0.0 if std == 0 else np.mean(((x - mean) / std) ** 3)
    return {"mean": mean, "std": std, "skewness": skew}


def hue_mean_sirkular(h_deg: np.ndarray, bobot: np.ndarray | None = None) -> float:
    """Rata-rata Hue yang benar (sirkular), karena 359 deg dan 1 deg bertetangga."""
    r = np.deg2rad(h_deg.ravel())
    w = np.ones_like(r) if bobot is None else bobot.ravel()
    sudut = np.rad2deg(np.arctan2((w * np.sin(r)).sum(), (w * np.cos(r)).sum()))
    return float(np.round(sudut, 6) % 360)


def hue_std_sirkular(h_deg: np.ndarray, bobot: np.ndarray | None = None) -> float:
    """Simpangan baku sirkular Hue (derajat): sqrt(-2 ln R)."""
    r = np.deg2rad(h_deg.ravel())
    w = np.ones_like(r) if bobot is None else bobot.ravel()
    R = np.hypot((w * np.sin(r)).sum(), (w * np.cos(r)).sum()) / w.sum()
    R = min(max(R, 1e-12), 1.0)
    return float(np.rad2deg(np.sqrt(-2.0 * np.log(R)))) + 0.0


def ekstrak_momen(rgb: np.ndarray) -> pd.DataFrame:
    hsv = rgb_ke_hsv(rgb)
    baris = []
    for i, n in enumerate(NAMA_KANAL_RGB):
        m = momen_warna(rgb[..., i]); baris.append({"Ruang": "RGB", "Kanal": n, **m})
    for i, n in enumerate(NAMA_KANAL_HSV):
        m = momen_warna(hsv[..., i])
        if n == "H":  # Hue bersifat sirkular -> mean & std sirkular, skewness tidak didefinisikan
            m["mean"] = hue_mean_sirkular(hsv[..., 0], hsv[..., 1])
            m["std"] = hue_std_sirkular(hsv[..., 0], hsv[..., 1])
            m["skewness"] = np.nan
        baris.append({"Ruang": "HSV", "Kanal": n, **m})
    return pd.DataFrame(baris)


def histogram_rgb(rgb: np.ndarray, bins: int = 256) -> np.ndarray:
    """Histogram ternormalisasi per kanal, bentuk (3, bins)."""
    return np.stack([
        cv2.calcHist([rgb], [c], None, [bins], [0, 256]).ravel() / (rgb.shape[0] * rgb.shape[1])
        for c in range(3)
    ])


def histogram_hsv(rgb: np.ndarray, bins_h=18, bins_s=4, bins_v=4) -> np.ndarray:
    """Histogram gabungan HSV (bins_h x bins_s x bins_v), ternormalisasi, diratakan."""
    hsv = cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV)
    h = cv2.calcHist([hsv], [0, 1, 2], None, [bins_h, bins_s, bins_v],
                     [0, 180, 0, 256, 0, 256])
    h = h.ravel()
    return h / h.sum()


def nama_warna(r: float, g: float, b: float) -> str:
    """Nama warna sederhana (aturan HSV) untuk satu warna RGB 0-255."""
    px = np.uint8([[[r, g, b]]])
    h, s, v = rgb_ke_hsv(px)[0, 0]
    if v < 0.15:
        return "Hitam"
    if s < 0.12:
        return "Putih" if v > 0.85 else "Abu-abu"
    batas = [(15, "Merah"), (45, "Oranye"), (70, "Kuning"), (165, "Hijau"),
             (200, "Cyan"), (260, "Biru"), (290, "Ungu"), (335, "Magenta/Pink"), (361, "Merah")]
    for b_atas, nama in batas:
        if h < b_atas:
            return nama
    return "Merah"


def warna_dominan(rgb: np.ndarray, k: int = 5, seed: int = 42) -> pd.DataFrame:
    """K-Means pada piksel RGB -> k warna dominan beserta persentasenya."""
    data = rgb.reshape(-1, 3).astype(np.float32)
    cv2.setRNGSeed(seed)
    kriteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.5)
    _, label, pusat = cv2.kmeans(data, k, None, kriteria, 3, cv2.KMEANS_PP_CENTERS)
    jumlah = np.bincount(label.ravel(), minlength=k)
    urut = np.argsort(-jumlah)
    baris = []
    for i in urut:
        r, g, b = np.clip(np.round(pusat[i]), 0, 255).astype(int)
        baris.append({"R": r, "G": g, "B": b, "HEX": f"#{r:02X}{g:02X}{b:02X}",
                      "Nama": nama_warna(r, g, b),
                      "Persentase (%)": 100.0 * jumlah[i] / jumlah.sum()})
    return pd.DataFrame(baris)


def vektor_fitur(rgb: np.ndarray) -> pd.Series:
    """Vektor fitur 1 baris: 18 momen warna (6 kanal x 3 momen)."""
    df = ekstrak_momen(rgb)
    nilai = {f"{r.Ruang}_{r.Kanal}_{m}": getattr(r, m)
             for r in df.itertuples() for m in ("mean", "std", "skewness")}
    return pd.Series(nilai)
