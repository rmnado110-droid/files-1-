"""
Aplikasi Ekstraksi Fitur Warna Citra - Streamlit
Jalankan:  streamlit run app_streamlit.py
"""
import numpy as np
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
import fitur_warna as fw

st.set_page_config(page_title="Ekstraksi Fitur Warna", layout="wide")
st.title("Ekstraksi Fitur Warna Citra Digital")
st.caption("Tugas Ekstraksi Fitur Citra - RGB, HSV, histogram, dan warna dominan")

with st.sidebar:
    st.header("Pengaturan")
    sisi = st.slider("Ukuran sisi terpanjang (px)", 100, 800, 400, 50)
    k = st.slider("Jumlah warna dominan (K)", 2, 10, 5)
    bins = st.select_slider("Jumlah bin histogram", [16, 32, 64, 128, 256], 256)

berkas = st.file_uploader("Unggah citra (JPG/PNG/BMP)", type=["jpg", "jpeg", "png", "bmp"])
if berkas is None:
    st.info("Unggah sebuah citra untuk memulai.")
    st.stop()

try:
    rgb = fw.ubah_ukuran(fw.baca_rgb(berkas.getvalue()), sisi)
except ValueError as e:
    st.error(str(e)); st.stop()

st.subheader("1. Citra Masukan")
c1, c2 = st.columns([1, 2])
c1.image(rgb, caption=f"{rgb.shape[1]} x {rgb.shape[0]} piksel", use_container_width=True)
hsv = fw.rgb_ke_hsv(rgb)
with c2:
    st.markdown("**Pemisahan kanal**")
    nol = np.zeros_like(rgb[..., 0])
    a, b, c = st.columns(3)
    a.image(np.dstack([rgb[..., 0], nol, nol]), caption="Kanal R", use_container_width=True)
    b.image(np.dstack([nol, rgb[..., 1], nol]), caption="Kanal G", use_container_width=True)
    c.image(np.dstack([nol, nol, rgb[..., 2]]), caption="Kanal B", use_container_width=True)

st.subheader("2. Momen Warna (mean, standar deviasi, skewness)")
momen = fw.ekstrak_momen(rgb)
st.dataframe(momen.style.format({"mean": "{:.3f}", "std": "{:.3f}", "skewness": "{:.3f}"}, na_rep="-"),
             use_container_width=True, hide_index=True)
st.caption("Satuan: RGB 0-255 | H dalam derajat (0-360), S dan V skala 0-1. Mean dan std Hue dihitung secara sirkular (skewness Hue tidak didefinisikan).")

st.subheader("3. Histogram Warna")
hist = fw.histogram_rgb(rgb, bins)
fig, ax = plt.subplots(1, 3, figsize=(12, 3))
for i, (n, w) in enumerate(zip(["Merah", "Hijau", "Biru"], ["red", "green", "blue"])):
    ax[i].bar(np.arange(bins), hist[i], color=w, width=1.0)
    ax[i].set_title(f"Histogram {n}"); ax[i].set_xlabel("Bin intensitas"); ax[i].set_ylabel("Proporsi")
fig.tight_layout(); st.pyplot(fig)

st.subheader("4. Warna Dominan (K-Means)")
dom = fw.warna_dominan(rgb, k)
fig2, ax2 = plt.subplots(figsize=(10, 1.2))
kiri = 0
for _, r in dom.iterrows():
    lebar = r["Persentase (%)"]
    ax2.barh(0, lebar, left=kiri, color=r["HEX"]); kiri += lebar
ax2.axis("off"); st.pyplot(fig2)
st.dataframe(dom.style.format({"Persentase (%)": "{:.2f}"}), use_container_width=True, hide_index=True)

st.subheader("5. Vektor Fitur & Unduh")
vf = fw.vektor_fitur(rgb)
st.dataframe(vf.to_frame("nilai").T, use_container_width=True)
st.download_button("Unduh vektor fitur (CSV)", vf.to_frame().T.to_csv(index=False).encode(),
                   file_name="fitur_warna.csv", mime="text/csv")
